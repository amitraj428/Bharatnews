if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('sw.js').then(function(reg) {
    console.log('Service Worker Registered!', reg);
  });
}

// News API से ऑटोमैटिक न्यूज़ लोड करना
const apiKey = '08fed99070f9442fbbedee3bc5fba0f5';
const url = `https://newsapi.org/v2/top-headlines?country=in&language=hi&apiKey=${apiKey}`;

fetch(url)
  .then(response => response.json())
  .then(data => {
    const newsContainer = document.getElementById("news");
    newsContainer.innerHTML = "";
    data.articles.forEach(article => {
      const newsItem = document.createElement("div");
      newsItem.className = "news-item";
      newsItem.innerHTML = `
        <h2>${article.title}</h2>
        <img src="${article.urlToImage || ''}" alt="News image" style="max-width: 100%;">
        <p>${article.description || ''}</p>
        <a href="${article.url}" target="_blank">पूरा पढ़ें</a>
        <hr>
      `;
      newsContainer.appendChild(newsItem);
    });
  })
  .catch(error => {
    document.getElementById("news").innerHTML = "समाचार लोड नहीं हो सके।";
    console.error("Error fetching news:", error);
  });
